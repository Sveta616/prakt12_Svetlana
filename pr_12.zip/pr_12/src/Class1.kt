class Class1 {
    fun Input():Int{
        println("Введите сколько раз хотите найти периметр фигур")
        val n= readLine()!!.toInt()
        if (n>0)
        {
            return n
        }
        else
        {
            println("Kоличество действий должно быть больше 0")
            return 1
        }
    }
    fun Per(){
      try {
            println("Введите первое число")
                var a = readLine()!!.toDouble()
        println("Введите второе число")
        var b= readLine()!!.toDouble()
        println("Введите третье число")
        var c= readLine()!!.toDouble()
        if(a>=0&&b>0&&c>0)
        {
            println("Выберите периметр какой фигуры вы хотите найти")
            println("1-Прямоугольник,2-Квадрат,3-Равносторонний треугольник")
            var v= readLine()!!.toInt()
            if (v == 1) {
                val otv1 = (a + b) * 2
                println("P=$otv1")
            } else
                if (v == 2) {
                    val otv2 = a * 4
                    println("P=$otv2")
                } else
                    if (v == 3) {
                        val otv3 = a + b + c
                        println("P=$otv3")
                    }
        else {
                        println("Такого действия нет")
                    }

    }else println("Периметр должен быть больше нуля")
      }catch(e:Exception)
      {
         println("Введите данные корректно")
      }

}
}