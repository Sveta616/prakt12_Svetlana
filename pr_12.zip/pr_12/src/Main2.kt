import kotlinx.coroutines.*
fun main()= runBlocking {
    var rep= mutableListOf<Class2>()
    var password=""
    var reposit=0
    var v=0
    while(true)
    {
        try{
        println("\nЗагрузите нового участника")
        print("Логин (exit для выхода)")
        val login= readLine()!!.toString()
        if(login=="exit") break
        println("Введите пароль не менее 8 символов")
        password= readLine()!!.toString()
        if(password.length>=8)
        {
            println("Введите кол-во репозиториев")
            reposit= readLine()!!.toInt()
            if(reposit>0)
            {
                println("Каким вы хотите сделать свой репозиорий? 1-Открытый,2-Закрытый")
                v= readLine()!!.toInt()
                if(v!=1&&v!=2)
                {
                    println("Такого действия нет")
                }
                val V:Boolean=v==1
                var r=Class2(login,password,reposit,V)
              rep.add(r)
            }
            else
            {
                println("Кол-во репозиториев не может быть <0")
            }
        }
        else
        {
            println("Пароль не может быть <8 символов")
        }
    }
        catch(e:Exception){
            println("Введите данные корректно")
        }
    }
    println("Загрузка, подождите немного, Loading")
    delay(3000)
    val sort=rep.first().sort(rep)
    sort.forEach {
        println(it.getInfo())
    }

}


