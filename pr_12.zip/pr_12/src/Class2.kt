import kotlinx.coroutines.delay
class Class2(var login:String,var password:String,var reposit:Int,var Open:Boolean) {
    suspend fun sort(repos:List<Class2>):List<Class2>
    {
        delay(2000L)
        return repos.filter { it.Open }.sortedWith(compareBy {reposit})
    }
    suspend fun  getInfo():String{
        delay(1000L)
        return "Логин: $login, Пароль: $password, Кол-во репозиториев: $reposit"
    }
}