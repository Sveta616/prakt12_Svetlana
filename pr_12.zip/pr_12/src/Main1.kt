import kotlinx.coroutines.*
suspend fun main()
{
    try {
        var class1: Class1 = Class1()
        var K = class1.Input()
        GlobalScope.launch {
            for (i in 1..K) {
                println("$i раз")
                class1.Per()
            }
        }
        runBlocking { delay(30000L) }
    }catch(E:Exception)
    {
        println("Введите данные корректно")
    }
}